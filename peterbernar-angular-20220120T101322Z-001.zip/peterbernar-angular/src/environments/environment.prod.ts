export const environment = {
  production: true,
  siteUrl: 'http://localhost/peterbernard_ci/index.php/',
};
