import { Bathroomsdetails } from './bathroomsdetails.model';

describe('Bathroomsdetails', () => {
  it('should create an instance', () => {
    expect(new Bathroomsdetails()).toBeTruthy();
  });
});
