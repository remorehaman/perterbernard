import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bedroomsdetails',
  templateUrl: './bedroomsdetails.component.html',
  styleUrls: ['./bedroomsdetails.component.css']
})
export class BedroomsdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
