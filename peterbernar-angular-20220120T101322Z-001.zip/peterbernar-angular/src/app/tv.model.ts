export class Tv {
    // public id : number;
    // public name : string
    // public image: string;
    // public text:string;
   

    // constructor(tvid:any,tvname:any,tvimage:any,tvtext:any)
    //     {
    //         this.id = tvid;
    //         this.name = tvname;         
    //         this.image = tvimage;
    //         this.text = tvtext;
        
    //     }

    id:number;
    name:string;
    image:string;
    text:string;


}

