export interface Search{
    thumb:string,
    title:string,
    descprition:string
}